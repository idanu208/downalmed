document.getElementById('downloadBtn').addEventListener('click', async () => {
  const url = document.getElementById('urlInput').value.trim();
  const platform = document.getElementById('platformSelect').value;
  const resultDiv = document.getElementById('result');
  
  if (!url) {
    resultDiv.innerHTML = '<p class="error">Masukkan URL terlebih dahulu.</p>';
    return;
  }

  resultDiv.innerHTML = '<p>Memproses...</p>';

  try {
    const response = await fetch('/api/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, platform })
    });
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Gagal memproses');
    }

    resultDiv.innerHTML = `
      <div class="success">
        <h3>${data.title || 'Media ditemukan'}</h3>
        ${data.thumbnail ? `<img src="${data.thumbnail}" alt="thumbnail" width="200">` : ''}
        <p>Platform: ${data.platform}</p>
        <a href="${data.downloadUrl}" target="_blank" rel="noopener noreferrer" class="download-link">Download</a>
      </div>
    `;
  } catch (error) {
    resultDiv.innerHTML = `<p class="error">Error: ${error.message}</p>`;
  }
});