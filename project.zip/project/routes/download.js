const express = require('express');
const router = express.Router();
const youtube = require('../utils/youtube');
const instagram = require('../utils/instagram');
const tiktok = require('../utils/tiktok');
// ... impor utilitas lainnya

// Deteksi platform berdasarkan URL
function detectPlatform(url) {
  if (url.includes('youtube.com') || url.includes('youtu.be')) return 'youtube';
  if (url.includes('instagram.com')) return 'instagram';
  if (url.includes('tiktok.com')) return 'tiktok';
  if (url.includes('facebook.com') || url.includes('fb.watch')) return 'facebook';
  if (url.includes('twitter.com') || url.includes('x.com')) return 'twitter';
  return null;
}

router.post('/', async (req, res) => {
  const { url, platform } = req.body;
  if (!url) return res.status(400).json({ error: 'URL tidak boleh kosong' });

  const detectedPlatform = platform || detectPlatform(url);
  if (!detectedPlatform) {
    return res.status(400).json({ error: 'Platform tidak dikenali atau tidak didukung' });
  }

  try {
    let result;
    switch (detectedPlatform) {
      case 'youtube':
        result = await youtube.download(url);
        break;
      case 'instagram':
        result = await instagram.download(url);
        break;
      case 'tiktok':
        result = await tiktok.download(url);
        break;
      // ... tambahkan case lain
      default:
        return res.status(400).json({ error: 'Platform tidak didukung' });
    }

    res.json({
      success: true,
      platform: detectedPlatform,
      title: result.title,
      downloadUrl: result.url,
      thumbnail: result.thumbnail,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Gagal mengambil media. Pastikan URL valid.' });
  }
});

module.exports = router;