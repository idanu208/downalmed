const instagramGetUrl = require('instagram-url-direct');

exports.download = async (url) => {
  const result = await instagramGetUrl(url);
  if (!result || result.urls_list.length === 0) {
    throw new Error('Tidak dapat mengambil media Instagram');
  }
  // Ambil media pertama (video/image)
  const mediaUrl = result.urls_list[0];
  return {
    title: 'Instagram Media',
    url: mediaUrl,
    thumbnail: mediaUrl, // atau bisa pakai thumbnail sendiri
  };
};