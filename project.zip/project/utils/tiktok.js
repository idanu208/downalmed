const axios = require('axios');
const cheerio = require('cheerio');

exports.download = async (url) => {
  try {
    // Gunakan layanan pihak ketiga seperti tikmate.cc atau lainnya
    // Ini hanya contoh menggunakan API publik sementara
    const response = await axios.get(`https://tikdown.org/id?url=${encodeURIComponent(url)}`);
    const $ = cheerio.load(response.data);
    const videoUrl = $('a[download]').attr('href');
    if (!videoUrl) throw new Error('Video tidak ditemukan');
    return {
      title: 'TikTok Video',
      url: videoUrl,
      thumbnail: '',
    };
  } catch (err) {
    throw new Error('Gagal mengambil video TikTok');
  }
};