const ytdl = require('ytdl-core');

exports.download = async (url) => {
  if (!ytdl.validateURL(url)) throw new Error('URL YouTube tidak valid');

  const info = await ytdl.getInfo(url);
  const format = ytdl.chooseFormat(info.formats, { quality: 'highestvideo' });

  return {
    title: info.videoDetails.title,
    url: format.url, // Ini adalah URL langsung video (bisa di-stream)
    thumbnail: info.videoDetails.thumbnails.pop().url,
  };
};